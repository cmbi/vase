Clazz.declarePackage ("J.adapter.readers.xml");
Clazz.declareInterface (J.adapter.readers.xml, "JmolXmlHandler");
