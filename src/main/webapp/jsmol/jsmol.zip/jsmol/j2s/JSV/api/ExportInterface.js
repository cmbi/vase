Clazz.declarePackage ("JSV.api");
Clazz.load (["JSV.api.JSVExporter"], "JSV.api.ExportInterface", null, function () {
Clazz.declareInterface (JSV.api, "ExportInterface", JSV.api.JSVExporter);
});
